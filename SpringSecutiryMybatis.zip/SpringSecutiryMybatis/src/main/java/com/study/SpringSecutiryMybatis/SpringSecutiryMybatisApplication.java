package com.study.SpringSecutiryMybatis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecutiryMybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecutiryMybatisApplication.class, args);
	}

}
