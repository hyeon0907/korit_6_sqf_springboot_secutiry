package com.study.SpringSecutiryMybatis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecutiryMybatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
